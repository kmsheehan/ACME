'use strict';

/* http://docs.angularjs.org/guide/dev_guide.e2e-testing */

describe('myApp', function() {
console.log('Hi');
  beforeEach(function() {
    browser().navigateTo('/');
  });


  it('should automatically redirect to /Listall when location hash/fragment is empty', function() {
    expect(browser().location().url()).toBe("/#/listall");
  });


  describe('Listall', function() {

    beforeEach(function() {
      browser().navigateTo('/view1');
    });


    it('should render Listall when user navigates to /Listall', function() {
      expect(element('[ng-view] p:first').text()).
        toMatch(/partial for view 1/);
    });

  });


  describe('SecondList', function() {

    beforeEach(function() {
      browser().navigateTo('/view2');
    });


    it('should render SecondList when user navigates to /view2', function() {
      expect(element('[ng-view] p:first').text()).
        toMatch(/partial for view 2/);
    });

  });
});
